"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LogTextColor_1 = require("C:/snapshot/project/obj/models/spt/logging/LogTextColor");
const LogBackgroundColor_1 = require("C:/snapshot/project/obj/models/spt/logging/LogBackgroundColor");
class Mod {
    postDBLoad(container) {
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        // Get all the in-memory json found in /assets/database
        const tables = databaseServer.getTables();
        // Find the location (customs for the first line) and set req player level
        tables.locations.bigmap.base.RequiredPlayerLevelMin = 15;
        tables.locations.factory4_day.base.RequiredPlayerLevelMin = 10;
        tables.locations.interchange.base.RequiredPlayerLevelMin = 25;
        tables.locations.tarkovstreets.base.RequiredPlayerLevelMin = 50;
        tables.locations.rezervbase.base.RequiredPlayerLevelMin = 15;
        tables.locations.woods.base.RequiredPlayerLevelMin = 5;
        // Lock previous maps
        tables.locations.bigmap.base.RequiredPlayerLevelMax = 30;
        tables.locations.factory4_day.base.RequiredPlayerLevelMax = 20;
        tables.locations.interchange.base.RequiredPlayerLevelMax = 30;
        tables.locations.tarkovstreets.base.RequiredPlayerLevelMax = 100;
        tables.locations.rezervbase.base.RequiredPlayerLevelMax = 30;
        tables.locations.woods.base.RequiredPlayerLevelMax = 15;
        // Access changes
        tables.locations.laboratory.base.AccessKeys = null;
        // Swap lighthouse and shoreline map pos
        tables.locations.shoreline.base.IconX = "137";
        tables.locations.shoreline.base.IconY = "173";
        tables.locations.lighthouse.base.IconX = "238";
        tables.locations.lighthouse.base.IconY = "85";
        // Log
        const logger = container.resolve("WinstonLogger");
        logger.logWithColor("Level Based Access enabled. Prepare for hell.", LogTextColor_1.LogTextColor.GREEN, LogBackgroundColor_1.LogBackgroundColor.BLACK);
        logger.warning("Please report bugs in the mod's comments.");
        logger.info("Any new restriction ideas (max player level, etc.)? Suggest them in the comments!");
        logger.warning("Level 50 locks most maps.");
        logger.logWithColor("Bots do not progress with the player (yet).", LogTextColor_1.LogTextColor.RED, LogBackgroundColor_1.LogBackgroundColor.BLACK);
    }
}
module.exports = { mod: new Mod() };
