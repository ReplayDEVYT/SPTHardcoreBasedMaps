import { DependencyContainer } from "tsyringe";
import { ILogger } from "@spt-aki/models/spt/utils/ILogger";
import { LogTextColor } from "@spt-aki/models/spt/logging/LogTextColor";
import { LogBackgroundColor } from "@spt-aki/models/spt/logging/LogBackgroundColor";
import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { IDatabaseTables } from "@spt-aki/models/spt/server/IDatabaseTables";

class Mod implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void 
    {
        // get database from server
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");

        // Get all the in-memory json found in /assets/database
        const tables: IDatabaseTables = databaseServer.getTables();

        // Find the location (customs for the first line) and set req player level
        tables.locations.bigmap.base.RequiredPlayerLevelMin = 15;
        tables.locations.factory4_day.base.RequiredPlayerLevelMin = 10;
        tables.locations.interchange.base.RequiredPlayerLevelMin = 25;
        tables.locations.tarkovstreets.base.RequiredPlayerLevelMin = 50;
        tables.locations.rezervbase.base.RequiredPlayerLevelMin = 15;
        tables.locations.woods.base.RequiredPlayerLevelMin = 5;

        // Lock previous maps
        tables.locations.bigmap.base.RequiredPlayerLevelMax = 30;
        tables.locations.factory4_day.base.RequiredPlayerLevelMax = 20;
        tables.locations.interchange.base.RequiredPlayerLevelMax = 40;
        tables.locations.tarkovstreets.base.RequiredPlayerLevelMax = 100;
        tables.locations.rezervbase.base.RequiredPlayerLevelMax = 30;
        tables.locations.woods.base.RequiredPlayerLevelMax = 15;
        
        // Access changes
        tables.locations.laboratory.base.AccessKeys = null
        
        // Swap lighthouse and shoreline map pos
        tables.locations.shoreline.base.IconX = "137"
        tables.locations.shoreline.base.IconY = "173"
        
        tables.locations.lighthouse.base.IconX = "238"
        tables.locations.lighthouse.base.IconY = "85"
        
        // Log
        const logger = container.resolve<ILogger>("WinstonLogger");
        
        logger.logWithColor("Level Based Access enabled. Prepare for hell.", LogTextColor.GREEN, LogBackgroundColor.BLACK)
        logger.warning("Please report bugs in the mod's comments.")
        logger.info("Any new restriction ideas (max player level, etc.)? Suggest them in the comments!")
        logger.warning("Level 50 locks most maps.")
        logger.logWithColor("Bots do not progress with the player (yet).", LogTextColor.RED, LogBackgroundColor.BLACK);

    }

    
}

module.exports = { mod: new Mod() }